"""
TransportPro — Application principale
Outil de gestion financière pour les petits transporteurs routiers.
"""

import streamlit as st

# Configuration de la page
st.set_page_config(
    page_title="TransportPro — Gestion financière transport",
    page_icon="🚛",
    layout="wide",
    initial_sidebar_state="expanded",
)

# --- CSS personnalisé ---
st.markdown(
    """
    <style>
        /* Style général */
        .stApp {
            font-family: 'Arial', sans-serif;
        }

        /* Sidebar */
        [data-testid="stSidebar"] {
            background-color: #111827;
        }

        /* Métriques */
        [data-testid="stMetricValue"] {
            font-size: 1.8rem;
            font-weight: 700;
        }

        /* Bouton principal */
        .stFormSubmitButton > button {
            background-color: #1B6EC2;
            color: white;
            font-size: 1.1rem;
            font-weight: 600;
            padding: 0.6rem 2rem;
            border: none;
            border-radius: 8px;
        }
        .stFormSubmitButton > button:hover {
            background-color: #155a9c;
        }

        /* Cacher le menu hamburger et le footer */
        #MainMenu {visibility: hidden;}
        footer {visibility: hidden;}

        /* Cards style pour les sections */
        .block-container {
            padding-top: 2rem;
        }
    </style>
    """,
    unsafe_allow_html=True,
)


# --- Sidebar navigation ---
with st.sidebar:
    st.markdown(
        """
        <div style="text-align: center; padding: 1rem 0;">
            <h1 style="color: #1B6EC2; font-size: 1.8rem; margin: 0;">
                🚛 TransportPro
            </h1>
            <p style="color: #888; font-size: 0.85rem; margin-top: 0.3rem;">
                Gestion financière transport
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.divider()

    page = st.radio(
        "Navigation",
        [
            "🏠 Accueil",
            "🧮 Calculateur Coût/km",
            "📈 Rentabilité Tournées",
            "💼 Dashboard Financier",
        ],
        label_visibility="collapsed",
    )

    st.divider()

    # Indicateur d'état
    if "resultat_km" in st.session_state:
        r = st.session_state["resultat_km"]
        st.success(f"✅ Profil véhicule configuré")
        st.caption(f"Coût réel : {r.cout_km_reel:.3f} €/km")
    else:
        st.info("ℹ️ Aucun profil véhicule configuré")

    st.divider()

    st.markdown(
        """
        <div style="text-align: center; padding: 1rem 0;">
            <p style="color: #555; font-size: 0.75rem;">
                TransportPro v0.1 — MVP<br>
                © 2026
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )


# --- Routage des pages ---
if page == "🏠 Accueil":
    # Page d'accueil
    st.markdown(
        """
        <div style="text-align: center; padding: 2rem 0;">
            <h1 style="color: #1B6EC2; font-size: 2.5rem; margin-bottom: 0.5rem;">
                🚛 TransportPro
            </h1>
            <p style="color: #ccc; font-size: 1.3rem; max-width: 700px; margin: 0 auto;">
                L'outil de gestion financière conçu pour les transporteurs routiers
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.divider()

    col1, col2, col3 = st.columns(3)

    with col1:
        st.markdown(
            """
            ### 🧮 Calculateur Coût/km
            **Gratuit**

            Calculez votre coût réel au kilomètre
            avec la méthode trinôme du CNR.
            Découvrez votre prix minimum à facturer.

            *→ Sélectionnez dans le menu à gauche*
            """
        )

    with col2:
        st.markdown(
            """
            ### 📈 Rentabilité Tournées
            **Essentiel — 29€/mois**

            Analysez la rentabilité de chaque tournée.
            Trouvez votre seuil de rentabilité et
            identifiez vos meilleurs clients.

            *🔒 Bientôt disponible*
            """
        )

    with col3:
        st.markdown(
            """
            ### 💼 Dashboard Financier
            **Pro — 49€/mois**

            FRNG, BFR, trésorerie nette, ratios
            financiers et alertes automatiques.
            Pilotez votre entreprise comme un pro.

            *🔒 Bientôt disponible*
            """
        )

    st.divider()

    st.markdown(
        """
        <div style="text-align: center; padding: 1rem 0;">
            <h3 style="color: #aaa;">Pourquoi TransportPro ?</h3>
        </div>
        """,
        unsafe_allow_html=True,
    )

    col1, col2, col3 = st.columns(3)

    with col1:
        st.markdown(
            """
            **Le problème**

            Les petits transporteurs fixent leurs prix
            au doigt mouillé. Avec des marges sectorielles
            de 2-3%, chaque erreur de tarification
            peut mettre en danger l'entreprise.
            """
        )

    with col2:
        st.markdown(
            """
            **La solution**

            TransportPro vous donne la visibilité
            financière que seuls les grands groupes
            ont via leurs TMS à 6 000€+, mais
            adapté à votre taille et votre budget.
            """
        )

    with col3:
        st.markdown(
            """
            **Pour qui ?**

            Transporteurs routiers de marchandises
            avec 1 à 15 camions qui veulent maîtriser
            leurs coûts, leurs marges et la santé
            financière de leur entreprise.
            """
        )

elif page == "🧮 Calculateur Coût/km":
    from modules.calculateur import afficher_calculateur
    afficher_calculateur()

elif page == "📈 Rentabilité Tournées":
    from modules.rentabilite import afficher_rentabilite
    afficher_rentabilite()

elif page == "💼 Dashboard Financier":
    from modules.dashboard import afficher_dashboard
    afficher_dashboard()
